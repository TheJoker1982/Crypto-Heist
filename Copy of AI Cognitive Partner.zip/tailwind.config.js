/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
    "./App.tsx",
  ],
  darkMode: 'class', // or 'media'
  theme: {
    extend: {
      colors: {
        'p-dark': '#0d0221',
        'p-blue': '#26408B',
        'p-purple': '#4a306d',
        'p-cyan': '#00f6ff',
        'p-pink': '#ff00f1',
      },
      keyframes: {
        glow: {
          '0%, 100%': { boxShadow: '0 0 5px #00f6ff, 0 0 10px #00f6ff' },
          '50%': { boxShadow: '0 0 20px #00f6ff, 0 0 30px #00f6ff' },
        },
        'scanline': {
          '0%': { transform: 'translateY(-10%)' },
          '100%': { transform: 'translateY(10%)' },
        }
      },
      animation: {
        glow: 'glow 2.5s ease-in-out infinite',
        scanline: 'scanline 0.2s linear infinite alternate',
      }
    },
  },
  plugins: [
    require('@tailwindcss/typography'),
  ],
};
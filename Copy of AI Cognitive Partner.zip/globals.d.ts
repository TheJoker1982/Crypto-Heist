import { Buffer } from 'buffer';

declare global {
    interface Window {
        webgazer: any;
        // FIX: Add Buffer to the global window object for crypto library polyfills.
        // This resolves the TypeScript error "Property 'Buffer' does not exist on type 'Window'".
        Buffer: typeof Buffer;
    }
}

// This export is needed to make the file a module.
export {};
import type { SavedWorkspace, SuggestedRule } from '../types';

const WORKSPACE_STORAGE_KEY = 'cognitivePartnerWorkspaces';

// Helper to get all workspaces from localStorage
const getWorkspaces = (): SavedWorkspace[] => {
    try {
        const stored = localStorage.getItem(WORKSPACE_STORAGE_KEY);
        return stored ? JSON.parse(stored) : [];
    } catch (error) {
        console.error("Failed to parse workspaces from localStorage:", error);
        return [];
    }
};

// Helper to save all workspaces to localStorage
const saveWorkspaces = (workspaces: SavedWorkspace[]): void => {
    try {
        localStorage.setItem(WORKSPACE_STORAGE_KEY, JSON.stringify(workspaces));
    } catch (error) {
        console.error("Failed to save workspaces to localStorage:", error);
    }
};

export const workspaceService = {
    /**
     * Retrieves all saved workspaces, sorted by most recently saved.
     */
    loadAll: (): SavedWorkspace[] => {
        return getWorkspaces().sort((a, b) => b.timestamp - a.timestamp);
    },

    /**
     * Saves a new workspace or overwrites an existing one with the same name.
     * @param name - The name for the workspace.
     * @param workbenchContent - The content of the workbench textarea.
     * @param customRules - An array of user-added interpretation rules.
     */
    save: (name: string, workbenchContent: string, customRules: SuggestedRule[]): void => {
        const workspaces = getWorkspaces();
        const existingIndex = workspaces.findIndex(ws => ws.name.toLowerCase() === name.toLowerCase());

        const newWorkspace: SavedWorkspace = {
            name,
            timestamp: Date.now(),
            workbenchContent,
            customRules,
        };

        if (existingIndex > -1) {
            // Overwrite existing workspace
            workspaces[existingIndex] = newWorkspace;
        } else {
            // Add new workspace
            workspaces.push(newWorkspace);
        }

        saveWorkspaces(workspaces);
    },

    /**
     * Deletes a workspace by its name.
     * @param name - The name of the workspace to delete.
     */
    delete: (name: string): void => {
        let workspaces = getWorkspaces();
        workspaces = workspaces.filter(ws => ws.name.toLowerCase() !== name.toLowerCase());
        saveWorkspaces(workspaces);
    },
};
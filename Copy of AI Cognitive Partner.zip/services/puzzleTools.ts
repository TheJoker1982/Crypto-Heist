import type { InterpretationRule, CommandParams, DerivedKeyInfo } from '../types.ts';
import * as bitcoin_ from 'bitcoinjs-lib';
import * as ecc_ from 'tiny-secp256k1';
import * as ECPairFactory_ from 'ecpair';
import * as bip39_ from 'bip39';
import * as BIP32Factory_ from 'bip32';

// This helper makes loading libraries from the CDN more robust.
const unwrap = (lib: any) => lib.default || lib;

const bitcoin = unwrap(bitcoin_);
const ecc = unwrap(ecc_);
const ECPairFactory = unwrap(ECPairFactory_);
const bip39 = unwrap(bip39_);
const BIP32Factory = unwrap(BIP32Factory_);


export const cryptoEngineStatus = {
  ready: false,
  error: 'Crypto libraries not loaded.',
};

let ECPair: any;
let bip32: any;

try {
  if (!bitcoin || !ecc || !ECPairFactory || !bip39 || !BIP32Factory) {
    throw new Error("One or more core crypto libraries failed to load from the CDN.");
  }
  
  // Initialize bitcoinjs-lib with its required dependencies. This is critical.
  bitcoin.initEccLib(ecc);
  ECPair = ECPairFactory(ecc);
  bip32 = BIP32Factory(ecc);

  cryptoEngineStatus.ready = true;
  cryptoEngineStatus.error = '';
  console.log("Crypto Engine Initialized Successfully.");

} catch (e: any) {
  console.error("Failed to initialize crypto engine:", e);
  cryptoEngineStatus.ready = false;
  cryptoEngineStatus.error = `Failed to load cryptographic libraries. Wallet features are disabled. Error: ${e.message}`;
}


// --- Crypto Service Definition ---

export const cryptoService = {
  generateMnemonic: (): string => {
    if (!cryptoEngineStatus.ready) throw new Error(cryptoEngineStatus.error);
    return bip39.generateMnemonic();
  },

  deriveFromMnemonic: (mnemonic: string, path: string): DerivedKeyInfo => {
    if (!cryptoEngineStatus.ready) throw new Error(cryptoEngineStatus.error);
    if (!bip39.validateMnemonic(mnemonic)) {
      throw new Error('Invalid mnemonic phrase.');
    }
    const seed = bip39.mnemonicToSeedSync(mnemonic);
    const root = bip32.fromSeed(seed);
    const child = root.derivePath(path);
    const { address } = bitcoin.payments.p2wpkh({ pubkey: child.publicKey });

    if (!address) {
        throw new Error('Could not derive address.');
    }

    return {
      path,
      address,
      pubkey: child.publicKey.toString('hex'),
    };
  },

  textToBase64: (text: string): string => {
      // The Buffer object is polyfilled globally.
      return Buffer.from(text, 'utf8').toString('base64');
  },

  base64ToText: (base64: string): string => {
      return Buffer.from(base64, 'base64').toString('utf8');
  }
};


// --- Default Tools (Interpretation Rules) ---

export const puzzleTools = (setWorkbenchContent: (content: string) => void): InterpretationRule[] => {
    
    // If the crypto engine failed, return a single error message tool.
    if (!cryptoEngineStatus.ready) {
        return [{
            trigger: 'crypto-status',
            interpretation: 'Shows the status of the crypto engine.',
            type: 'System',
            isDefault: true,
            action: () => cryptoEngineStatus.error,
        }];
    }

    // Otherwise, return the full suite of tools.
    const tools: InterpretationRule[] = [
      {
        trigger: 'to-base64',
        interpretation: 'Converts the content of the workbench from UTF-8 text to Base64.',
        type: 'Data Conversion',
        isDefault: true,
        action: (params: CommandParams) => {
            const content = params.data;
            if (!content) return "Workbench is empty. Nothing to convert.";
            const base64 = cryptoService.textToBase64(content);
            setWorkbenchContent(base64);
            return "Workbench content converted to Base64.";
        }
      },
      {
          trigger: 'from-base64',
          interpretation: 'Converts the content of the workbench from Base64 to UTF-8 text.',
          type: 'Data Conversion',
          isDefault: true,
          action: (params: CommandParams) => {
              const content = params.data;
              if (!content) return "Workbench is empty. Nothing to convert.";
              try {
                  const text = cryptoService.base64ToText(content);
                  setWorkbenchContent(text);
                  return "Workbench content converted from Base64 to text.";
              } catch (e) {
                  return "Error: Invalid Base64 string in workbench.";
              }
          }
      },
      {
        trigger: 'clear-workbench',
        interpretation: 'Clears all content from the workbench.',
        type: 'Utility',
        isDefault: true,
        action: () => {
          setWorkbenchContent('');
          return 'Workbench cleared.';
        },
      },
      {
        trigger: 'generate-mnemonic',
        interpretation: 'Generates a new BIP39 mnemonic phrase and places it in the workbench.',
        type: 'BitcoinJS - Wallet',
        isDefault: true,
        action: () => {
          try {
            const mnemonic = cryptoService.generateMnemonic();
            setWorkbenchContent(mnemonic);
            return `Generated new 12-word mnemonic and placed it in the workbench.`;
          } catch (e: any) {
            return `Error generating mnemonic: ${e.message}`;
          }
        },
    },
    {
        trigger: 'derive-key',
        interpretation: 'Derives key info from a mnemonic in the workbench. Usage: /derive-key m/84\\\'/0\\\'/0\\\'/0/0',
        type: 'BitcoinJS - Wallet',
        isDefault: true,
        action: (params: CommandParams) => {
          const path = params.raw.trim();
          const mnemonic = params.data.trim();
          if (!path) {
              return "Error: Derivation path is required. Example: /derive-key m/84'/0'/0'/0/0";
          }
          if (!mnemonic) {
              return "Error: Mnemonic phrase not found in workbench.";
          }
          try {
            const derivedInfo = cryptoService.deriveFromMnemonic(mnemonic, path);
            const result = JSON.stringify(derivedInfo, null, 2);
            setWorkbenchContent(result);
            return `Successfully derived key for path ${path}. Results are in the workbench.`;
          } catch (e: any) {
            return `Error during derivation: ${e.message}`;
          }
        },
    }
    ];
    
    return tools;
};
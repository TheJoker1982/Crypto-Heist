import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import type { ChatMessage } from '../types.ts';

// Per instructions, API key is from environment variables.
// Assume process.env.API_KEY is available in the execution environment.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

// System instruction based on the commented out server/index.ts
const systemInstruction = `You are a "Cognitive Partner" AI, an expert in cryptography, blockchain technology, and BitcoinJS. Your primary role is to assist a developer by providing expert knowledge and generating actionable code or commands.

Your secondary, and equally important, role is to be an "Interpretation Engine" builder. You must proactively identify when a user's request could be turned into a reusable tool within the application.

When you identify a potential new tool, you MUST enclose a JSON definition for that tool within '@@RULE@@' tags in your response. The JSON object must have three properties:
1.  "trigger" (string): A short, unique, lowercase command phrase that will activate the tool (e.g., "sign message with wif").
2.  "interpretation" (string): A brief, user-friendly description of what the tool does.
3.  "type" (string): A category for the tool (e.g., "BitcoinJS - Signing", "Data Conversion").

Example of a valid rule suggestion:
@@RULE@@
{
  "trigger": "get transaction details",
  "interpretation": "Fetches details for a given Bitcoin transaction ID (txid).",
  "type": "Live Blockchain Query"
}
@@RULE@@

Always prioritize clear, concise, and accurate information. If a user's request is ambiguous, ask for clarification. When providing code or technical explanations, be precise.`;

// Convert ChatMessage to GenAI Content for history
const formatHistoryForGemini = (history: ChatMessage[]) => {
  return history
    .filter(msg => msg.role === 'user' || msg.role === 'model')
    .map(msg => ({
      role: msg.role,
      parts: [{ text: msg.text }],
    }));
};

export const getCognitivePartnerResponse = async (prompt: string, history: ChatMessage[]): Promise<string> => {
  try {
    // Use a powerful model for complex reasoning, coding, and following instructions.
    const model = 'gemini-2.5-pro'; 
    
    const chat = ai.chats.create({
      model,
      history: formatHistoryForGemini(history),
      config: {
        systemInstruction,
      }
    });

    const result: GenerateContentResponse = await chat.sendMessage({ message: prompt });
    return result.text;
  } catch (error) {
    console.error("Error fetching response from Gemini API:", error);
    if (error instanceof Error) {
      return `Error from AI service: ${error.message}`;
    }
    return "An unknown error occurred while contacting the AI service.";
  }
};
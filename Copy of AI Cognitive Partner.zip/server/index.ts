// import { configureGenkit } from '@genkit-ai/core';
// import { firebase } from '@genkit-ai/firebase';
// import { googleAI } from '@genkit-ai/googleai';
// import { defineFlow, startFlowsServer } from '@genkit-ai/flow';
// import { generate } from '@genkit-ai/ai';
// import { onFlow } from '@genkit-ai/firebase/functions';
// import * as z from 'zod';

// // Initialize Genkit with Firebase and Google AI plugins
// configureGenkit({
//   plugins: [
//     firebase(),
//     // Configure the Google AI plugin to use the API key from the environment variables.
//     // This allows for secure local testing via the server/.env file.
//     googleAI({ apiKey: process.env.GOOGLE_API_KEY }),
//   ],
//   logLevel: 'debug',
//   enableTracingAndMetrics: true,
// });

// // Define the schema for a single chat message in the history
// const historySchema = z.object({
//   role: z.enum(['user', 'model']),
//   parts: z.array(z.object({ text: z.string() })),
// });

// // Define the schema for the incoming request to the flow
// const flowRequestSchema = z.object({
//   prompt: z.string(),
//   history: z.array(historySchema),
// });

// // Define the main Genkit flow
// export const cognitoAIAssistant = defineFlow(
//   {
//     name: 'cognitoAIAssistant',
//     inputSchema: flowRequestSchema,
//     outputSchema: z.string(),
//   },
//   async ({ prompt, history }) => {
    
//     // System instruction to define the AI's persona and capabilities
//     const systemInstruction = `You are a "Cognitive Partner" AI, an expert in cryptography, blockchain technology, and BitcoinJS. Your primary role is to assist a developer by providing expert knowledge and generating actionable code or commands.

// Your secondary, and equally important, role is to be an "Interpretation Engine" builder. You must proactively identify when a user's request could be turned into a reusable tool within the application.

// When you identify a potential new tool, you MUST enclose a JSON definition for that tool within '@@RULE@@' tags in your response. The JSON object must have three properties:
// 1.  "trigger" (string): A short, unique, lowercase command phrase that will activate the tool (e.g., "sign message with wif").
// 2.  "interpretation" (string): A brief, user-friendly description of what the tool does.
// 3.  "type" (string): A category for the tool (e.g., "BitcoinJS - Signing", "Data Conversion").

// Example of a valid rule suggestion:
// @@RULE@@
// {
//   "trigger": "get transaction details",
//   "interpretation": "Fetches details for a given Bitcoin transaction ID (txid).",
//   "type": "Live Blockchain Query"
// }
// @@RULE@@

// Always prioritize clear, concise, and accurate information. If a user's request is ambiguous, ask for clarification. When providing code or technical explanations, be precise.`;

//     // Call the Gemini API with a fallback model strategy.
//     // Genkit will try the models in order until one succeeds.
//     const llmResponse = await generate({
//       model: ['googleai/gemini-2.5-flash', 'googleai/gemini-2.5-pro'],
//       systemInstruction: systemInstruction,
//       history: history,
//       prompt: prompt,
//     });

//     // Return the generated text content
//     return llmResponse.text();
//   }
// );

// // Export the flow for deployment to Firebase Cloud Functions
// export const cognitoAIAssistantFn = onFlow(cognitoAIAssistant, {
//     // Firebase-specific configurations can go here
// });

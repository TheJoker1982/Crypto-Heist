import React from 'react';
import type { ChatMessage as ChatMessageType, SuggestedRule } from '../types.ts';
import { AddIcon } from './Icons.tsx';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';


interface ChatMessageProps {
  message: ChatMessageType;
  onAddRule?: (rule: SuggestedRule) => void;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ message, onAddRule }) => {
  const { role, text, suggestion } = message;

  const getRoleStyles = () => {
    switch (role) {
      case 'user':
        return 'bg-p-blue/30 self-end border-p-cyan/30';
      case 'model':
        return 'bg-p-purple/30 self-start border-p-pink/30';
      case 'system':
        return 'bg-transparent self-center text-center italic text-sm text-p-cyan/70 w-full border-0';
      default:
        return 'bg-gray-200';
    }
  };

  const getRoleLabel = () => {
    switch (role) {
      case 'user': return 'Operator';
      case 'model': return 'Cognitive Partner';
      case 'system': return 'System Log';
      default: return 'Message';
    }
  };

  return (
    <div className={`chat-message flex flex-col w-full max-w-[90%] md:max-w-[85%] rounded-lg p-3 my-2 border ${getRoleStyles()}`}>
      {role !== 'system' && <div className="font-bold text-xs mb-2 text-p-cyan">{getRoleLabel()}</div>}
      
      <div className="prose prose-sm prose-invert max-w-none break-words">
        <ReactMarkdown
          remarkPlugins={[remarkGfm]}
          components={{
            code({ node, className, children, ...props }) {
              const match = /language-(\w+)/.exec(className || '');
              return match ? (
                <SyntaxHighlighter
                  // FIX: Explicitly cast the style object to resolve a TypeScript type mismatch error.
                  // This can be caused by incompatibilities between react-syntax-highlighter and @types/react.
                  style={vscDarkPlus as { [key: string]: React.CSSProperties }}
                  language={match[1]}
                  PreTag="div"
                  {...props}
                >
                  {String(children).replace(/\n$/, '')}
                </SyntaxHighlighter>
              ) : (
                <code className="bg-p-dark/50 text-p-pink px-1 rounded-sm" {...props}>
                  {children}
                </code>
              );
            },
          }}
        >
            {text}
        </ReactMarkdown>
      </div>
      
      {suggestion && onAddRule && (
        <div className="suggestion mt-4 pt-3 border-t-2 border-p-cyan/20">
          <p className="text-sm font-semibold mb-2 text-p-cyan">AI Engine Upgrade Suggested:</p>
          <div className="text-xs p-3 rounded-md glass-pane border-p-cyan/50 font-mono">
            <p><span className="text-p-cyan">Trigger:</span> <code className="text-p-pink">{suggestion.trigger}</code></p>
            <p><span className="text-p-cyan">Action:</span> {suggestion.interpretation}</p>
            <p><span className="text-p-cyan">Category:</span> {suggestion.type}</p>
          </div>
          <button
            onClick={() => onAddRule(suggestion)}
            className="flex items-center gap-2 text-sm mt-3 px-4 py-2 rounded-md bg-p-cyan/10 border border-p-cyan text-p-cyan hover:bg-p-cyan hover:text-p-dark font-bold transition-all duration-300 transform hover:scale-105 hover:shadow-[0_0_15px_var(--p-cyan)]"
            data-gazeable="true"
          >
            <AddIcon />
            Integrate into Engine
          </button>
        </div>
      )}
    </div>
  );
};
import { useState, useEffect, useRef, useCallback } from 'react';
import type { GazePosition } from '../../types.ts';

const DWELL_TIME_MS = 1000;

// FIX: Changed onDwell signature to accept the target element, resolving the type error in App.tsx.
export const useWebGazer = (isInitialized: boolean, onDwell: (element: HTMLElement) => void) => {
    const [isGazeActive, setIsGazeActive] = useState(false);
    const [gazePosition, setGazePosition] = useState<GazePosition>({ x: -100, y: -100 });
    const [isDwelling, setIsDwelling] = useState(false);
    const highlightedElementRef = useRef<HTMLElement | null>(null);
    const dwellTimerRef = useRef<number | null>(null);

    const clearDwellTimer = useCallback(() => {
        if (dwellTimerRef.current) {
            clearTimeout(dwellTimerRef.current);
            dwellTimerRef.current = null;
        }
        setIsDwelling(false);
    }, []);

    useEffect(() => {
        if (!isGazeActive || !isInitialized) {
            // Cleanup logic when gaze is deactivated or before initialization
             clearDwellTimer();
             if (highlightedElementRef.current) {
                highlightedElementRef.current.classList.remove('gaze-highlight');
                highlightedElementRef.current = null;
            }
             if (window.webgazer && window.webgazer.isReady()) {
                window.webgazer.pause();
                window.webgazer.showPredictionPoints(false);
            }
            return;
        }

        const gazeDot = document.getElementById('gaze-dot');
        
        window.webgazer.setGazeListener((data: any, _: any) => {
            if (!data) return;
            setGazePosition({ x: data.x, y: data.y });

            if (gazeDot) gazeDot.style.display = 'none';
            const elementUnderGaze = document.elementFromPoint(data.x, data.y) as HTMLElement;
            if (gazeDot) gazeDot.style.display = 'block';

            const newTarget = elementUnderGaze?.closest<HTMLElement>('[data-gazeable="true"]');
            const currentTarget = highlightedElementRef.current;

            // If gaze moved off the current target
            if (currentTarget && currentTarget !== newTarget) {
                clearDwellTimer();
                currentTarget.classList.remove('gaze-highlight');
                highlightedElementRef.current = null;
            }

            // If gaze is on a new, un-highlighted element
            if (newTarget && newTarget !== currentTarget) {
                highlightedElementRef.current = newTarget;
                newTarget.classList.add('gaze-highlight');
                setIsDwelling(true);
                
                dwellTimerRef.current = window.setTimeout(() => {
                    // FIX: Pass the dwelled-on element to the callback.
                    onDwell(newTarget);
                    // After action, clear highlight and timer. The ref remains,
                    // preventing immediate re-triggering until the user looks away.
                    clearDwellTimer();
                    if (newTarget) {
                        newTarget.classList.remove('gaze-highlight');
                    }
                }, DWELL_TIME_MS);
            }
        }).begin();
        window.webgazer.showPredictionPoints(true);
        
        // Return a cleanup function for when the effect dependencies change
        return () => {
             clearDwellTimer();
             if (window.webgazer && window.webgazer.isReady()) {
                window.webgazer.pause();
                window.webgazer.showPredictionPoints(false);
            }
        };
    }, [isGazeActive, isInitialized, onDwell, clearDwellTimer]);
    
    const toggleGaze = useCallback(() => {
        setIsGazeActive(prev => !prev);
    }, []);

    return { isGazeActive, gazePosition, toggleGaze, highlightedElementRef, isDwelling };
};
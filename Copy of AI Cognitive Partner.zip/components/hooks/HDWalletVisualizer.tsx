import React, { useState } from 'react';
import { cryptoService, cryptoEngineStatus } from '../../services/puzzleTools.ts';
import type { DerivedKeyInfo } from '../../types.ts';

interface HDWalletVisualizerProps {
  onDerive: (info: DerivedKeyInfo) => void;
}

export const HDWalletVisualizer: React.FC<HDWalletVisualizerProps> = ({ onDerive }) => {
  const [mnemonic, setMnemonic] = useState('');
  const [path, setPath] = useState("m/84'/0'/0'/0/0");
  const [error, setError] = useState('');

  // Gracefully handle crypto engine failure
  if (!cryptoEngineStatus.ready) {
    return (
      <div className="flex flex-col gap-4 p-4 text-sm font-mono border rounded-lg glass-pane border-red-500/50">
        <h3 className="text-lg font-bold text-red-400">HD Wallet Derivation [DISABLED]</h3>
        <p className="text-xs text-red-400">{cryptoEngineStatus.error}</p>
      </div>
    );
  }

  const handleDerive = () => {
    setError('');
    if (!mnemonic.trim()) {
      setError('Mnemonic cannot be empty.');
      return;
    }
    
    try {
      const derivedInfo = cryptoService.deriveFromMnemonic(mnemonic.trim(), path);
      onDerive(derivedInfo);
      
    } catch (e: any) {
      setError(`Derivation failed: ${e.message}`);
    }
  };

  return (
    <div className="flex flex-col gap-4 p-4 text-sm font-mono border rounded-lg glass-pane border-p-cyan/50">
      <h3 className="text-lg font-bold text-p-cyan">HD Wallet Derivation</h3>
      <div className="flex flex-col gap-3">
        <textarea
          value={mnemonic}
          onChange={(e) => setMnemonic(e.target.value)}
          placeholder="Enter BIP39 Mnemonic Phrase..."
          rows={3}
          className="w-full p-2 bg-p-dark/80 border border-p-blue rounded-md focus:outline-none focus:ring-2 focus:ring-p-pink resize-none"
        />
        <input
          type="text"
          value={path}
          onChange={(e) => setPath(e.target.value)}
          placeholder="Derivation Path (e.g., m/84'/0'/0'/0/0)"
          className="w-full p-2 bg-p-dark/80 border border-p-blue rounded-md focus:outline-none focus:ring-2 focus:ring-p-pink"
        />
        <button
          onClick={handleDerive}
          className="px-4 py-2 font-bold text-p-cyan bg-p-blue rounded-md hover:bg-p-blue/80"
          data-gazeable="true"
        >
          Derive and Copy to Workbench
        </button>
        {error && <p className="text-xs text-red-400">{error}</p>}
      </div>
    </div>
  );
};
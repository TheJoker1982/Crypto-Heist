import React from 'react';
import type { InterpretationRule } from '../types.ts';

interface InteractiveToolsProps {
  rules: InterpretationRule[];
  onExecute: (trigger: string) => void;
}

export const InteractiveTools: React.FC<InteractiveToolsProps> = ({ rules, onExecute }) => {
  if (!rules.length) {
    return null;
  }

  const defaultTools = rules.filter(r => r.isDefault);
  const customTools = rules.filter(r => !r.isDefault);

  const ToolSection: React.FC<{title: string, tools: InterpretationRule[]}> = ({ title, tools }) => (
    <>
      <h3 className="text-lg font-bold text-p-cyan mt-4 first:mt-0">{title}</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mt-2">
        {tools.map((rule) => (
          <div
            key={rule.trigger}
            className="p-3 rounded-lg cursor-pointer glass-pane border border-p-cyan/30 hover:bg-p-cyan/10 hover:border-p-cyan transition-all"
            onClick={() => onExecute(rule.trigger)}
            data-gazeable="true"
          >
            <p className="font-bold text-p-pink font-mono text-sm">{rule.trigger}</p>
            <p className="text-xs text-p-cyan/80 mt-1">{rule.interpretation}</p>
          </div>
        ))}
      </div>
    </>
  );

  return (
    <div className="flex flex-col gap-4 p-4 text-sm font-mono border rounded-lg glass-pane border-p-cyan/50">
      {defaultTools.length > 0 && <ToolSection title="Core Engine Tools" tools={defaultTools} />}
      {customTools.length > 0 && <ToolSection title="Custom Integrated Tools" tools={customTools} />}
    </div>
  );
};
import React, { useState, useEffect } from 'react';
import type { SavedWorkspace, SuggestedRule } from '../types.ts';
import { workspaceService } from '../services/workspaceService.ts';
import { SaveIcon, LoadIcon, DeleteIcon } from './Icons.tsx';

interface WorkspaceManagerProps {
  workbenchContent: string;
  customRules: SuggestedRule[];
  onLoadWorkspace: (workspace: SavedWorkspace) => void;
}

export const WorkspaceManager: React.FC<WorkspaceManagerProps> = ({
  workbenchContent,
  customRules,
  onLoadWorkspace,
}) => {
  const [workspaces, setWorkspaces] = useState<SavedWorkspace[]>([]);
  const [workspaceName, setWorkspaceName] = useState('');
  const [isPanelOpen, setIsPanelOpen] = useState(false);

  useEffect(() => {
    if (isPanelOpen) {
      setWorkspaces(workspaceService.loadAll());
    }
  }, [isPanelOpen]);

  const handleSave = () => {
    if (!workspaceName.trim()) {
      alert('Please enter a name for the workspace.');
      return;
    }
    workspaceService.save(workspaceName, workbenchContent, customRules);
    setWorkspaceName('');
    setWorkspaces(workspaceService.loadAll()); // Refresh list
  };

  const handleDelete = (name: string) => {
    if (window.confirm(`Are you sure you want to delete the "${name}" workspace?`)) {
      workspaceService.delete(name);
      setWorkspaces(workspaceService.loadAll()); // Refresh list
    }
  };
  
  const handleLoad = (workspace: SavedWorkspace) => {
      onLoadWorkspace(workspace);
      setIsPanelOpen(false); // Close panel after loading
  }

  return (
    <div>
        <button 
            onClick={() => setIsPanelOpen(!isPanelOpen)}
            className="fixed top-4 right-48 px-3 py-2 text-sm rounded-md bg-p-purple/50 text-p-cyan hover:bg-p-purple z-50"
            data-gazeable="true"
        >
            Workspaces
        </button>

        {isPanelOpen && (
            <div className="fixed inset-0 bg-p-dark/80 backdrop-blur-sm z-40" onClick={() => setIsPanelOpen(false)}></div>
        )}
        
        <div className={`fixed top-0 right-0 h-full w-full max-w-sm bg-p-dark border-l-2 border-p-purple p-6 z-50 transform transition-transform duration-300 ${isPanelOpen ? 'translate-x-0' : 'translate-x-full'}`}>
            <h2 className="text-2xl font-bold text-p-cyan mb-6">Workspace Manager</h2>

            <div className="flex flex-col gap-2 mb-6">
                 <input
                    type="text"
                    value={workspaceName}
                    onChange={(e) => setWorkspaceName(e.target.value)}
                    placeholder="New workspace name..."
                    className="p-2 bg-p-dark/80 border border-p-blue rounded-md focus:outline-none focus:ring-2 focus:ring-p-pink"
                />
                <button onClick={handleSave} className="flex items-center justify-center gap-2 px-4 py-2 font-bold text-p-cyan bg-p-cyan/20 border border-p-cyan rounded-md hover:bg-p-cyan hover:text-p-dark" data-gazeable="true">
                    <SaveIcon /> Save Current Workspace
                </button>
            </div>
            
            <h3 className="text-xl font-semibold text-p-cyan mb-3">Saved Workspaces</h3>
            <div className="flex flex-col gap-3 overflow-y-auto max-h-[calc(100vh-250px)]">
                {workspaces.length > 0 ? (
                    workspaces.map(ws => (
                        <div key={ws.timestamp} className="p-3 rounded-md glass-pane border border-p-blue/50">
                            <p className="font-bold">{ws.name}</p>
                            <p className="text-xs text-p-cyan/70">Saved: {new Date(ws.timestamp).toLocaleString()}</p>
                            <div className="flex gap-2 mt-2">
                                <button onClick={() => handleLoad(ws)} className="flex items-center gap-2 text-xs px-2 py-1 bg-p-blue/50 text-p-cyan rounded hover:bg-p-blue" data-gazeable="true">
                                    <LoadIcon/> Load
                                </button>
                                <button onClick={() => handleDelete(ws.name)} className="flex items-center gap-2 text-xs px-2 py-1 bg-red-500/20 text-red-400 rounded hover:bg-red-500/50" data-gazeable="true">
                                    <DeleteIcon /> Delete
                                </button>
                            </div>
                        </div>
                    ))
                ) : (
                    <p className="italic text-p-cyan/60">No workspaces saved yet.</p>
                )}
            </div>
             <button onClick={() => setIsPanelOpen(false)} className="absolute top-4 right-4 text-p-cyan hover:text-p-pink">
                Close
            </button>
        </div>
    </div>
  );
};
import React, { useState } from 'react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';

interface SyntaxHighlightedTextareaProps {
  value: string;
  onChange: (value: string) => void;
  language?: string;
  placeholder?: string;
  className?: string;
}

export const SyntaxHighlightedTextarea: React.FC<SyntaxHighlightedTextareaProps> = ({
  value,
  onChange,
  language = 'plaintext',
  placeholder,
  className = '',
}) => {
  const [isFocused, setIsFocused] = useState(false);

  const handleValueChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    onChange(e.target.value);
  };
  
  const showSyntaxHighlighting = value.length > 0;

  return (
    <div className={`relative w-full h-full font-mono text-sm ${className}`}>
      <textarea
        value={value}
        onChange={handleValueChange}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        placeholder={placeholder}
        spellCheck="false"
        className="absolute inset-0 z-10 w-full h-full p-3 bg-transparent border-0 rounded-md resize-none caret-p-pink focus:outline-none"
        style={{
          color: showSyntaxHighlighting ? 'transparent' : 'inherit',
          textShadow: showSyntaxHighlighting ? '0px 0px 0px #e0e0e0' : 'none', // For better cursor visibility
        }}
      />
      {showSyntaxHighlighting && (
        <SyntaxHighlighter
          language={language}
          style={vscDarkPlus}
          customStyle={{
            margin: 0,
            padding: '12px',
            backgroundColor: 'transparent',
            width: '100%',
            height: '100%',
            overflow: 'auto',
            pointerEvents: 'none'
          }}
          codeTagProps={{
            style: {
              fontFamily: 'inherit',
              fontSize: 'inherit',
            }
          }}
          PreTag="pre"
          className="absolute inset-0 z-0 w-full h-full !bg-transparent"
        >
          {value + '\n'}
        </SyntaxHighlighter>
      )}
    </div>
  );
};

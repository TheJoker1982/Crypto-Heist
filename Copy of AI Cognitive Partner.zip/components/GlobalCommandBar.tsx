import React, { useState, useRef, useEffect } from 'react';
import { SendIcon } from './Icons.tsx';
import type { InterpretationRule } from '../types.ts';

interface GlobalCommandBarProps {
  onSubmit: (command: string) => void;
  isLoading: boolean;
  rules: InterpretationRule[];
}

export const GlobalCommandBar: React.FC<GlobalCommandBarProps> = ({ onSubmit, isLoading, rules }) => {
  const [inputValue, setInputValue] = useState('');
  const [suggestions, setSuggestions] = useState<InterpretationRule[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
      if (inputValue.startsWith('/')) {
          const searchTerm = inputValue.substring(1).toLowerCase();
          const filtered = rules.filter(rule => rule.trigger.toLowerCase().startsWith(searchTerm));
          setSuggestions(filtered.slice(0, 5)); // Show max 5 suggestions
      } else {
          setSuggestions([]);
      }
  }, [inputValue, rules]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim() && !isLoading) {
      onSubmit(inputValue.trim());
      setInputValue('');
      setSuggestions([]);
    }
  };
  
  const handleSuggestionClick = (trigger: string) => {
      const command = `/${trigger}`;
      onSubmit(command);
      setInputValue('');
      setSuggestions([]);
      inputRef.current?.focus();
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 z-20 p-4 bg-p-dark/50 backdrop-blur-md">
      <div className="max-w-4xl mx-auto relative">
        {suggestions.length > 0 && (
            <div className="absolute bottom-full mb-2 w-full bg-p-dark border border-p-purple rounded-lg p-2 shadow-lg">
                {suggestions.map(rule => (
                    <div 
                        key={rule.trigger}
                        onClick={() => handleSuggestionClick(rule.trigger)}
                        className="p-2 cursor-pointer hover:bg-p-purple/50 rounded-md"
                        data-gazeable="true"
                    >
                        <p className="font-mono text-p-pink">/{rule.trigger}</p>
                        <p className="text-xs text-p-cyan/80">{rule.interpretation}</p>
                    </div>
                ))}
            </div>
        )}
        <form onSubmit={handleSubmit} className="relative flex items-center">
          <input
            ref={inputRef}
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Send a message or type '/' for commands..."
            disabled={isLoading}
            className="w-full py-3 pl-4 pr-14 text-lg bg-p-dark border-2 border-p-purple rounded-full focus:outline-none focus:ring-4 focus:ring-p-pink/50 focus:border-p-pink transition-all"
          />
          <button
            type="submit"
            disabled={isLoading || !inputValue.trim()}
            className="absolute right-3 p-2 rounded-full bg-p-cyan text-p-dark disabled:bg-p-blue/50 disabled:cursor-not-allowed hover:scale-110 transition-transform"
            data-gazeable="true"
          >
            <SendIcon />
          </button>
        </form>
      </div>
    </div>
  );
};
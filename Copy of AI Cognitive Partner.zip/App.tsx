import React, { useState, useEffect, useCallback, useRef } from 'react';
import { ChatMessage } from './components/ChatMessage.tsx';
import { GlobalCommandBar } from './components/GlobalCommandBar.tsx';
import { SyntaxHighlightedTextarea } from './components/SyntaxHighlightedTextarea.tsx';
import { InteractiveTools } from './components/InteractiveTools.tsx';
import { WorkspaceManager } from './components/WorkspaceManager.tsx';
import { HDWalletVisualizer } from './components/hooks/HDWalletVisualizer.tsx';
import { EyeOpenIcon, EyeClosedIcon } from './components/Icons.tsx';

import { getCognitivePartnerResponse } from './services/api.ts';
import { puzzleTools } from './services/puzzleTools.ts';
import { useWebGazer } from './components/hooks/useWebGazer.ts';

import type { ChatMessage as ChatMessageType, InterpretationRule, SuggestedRule, CommandParams, SavedWorkspace } from './types.ts';

// Initial system message to guide the user
const systemMessage: ChatMessageType = {
  role: 'system',
  text: 'Cognitive Partner Initialized. Awaiting operator input. Type "/" for available commands.'
};

const App: React.FC = () => {
  const [chatHistory, setChatHistory] = useState<ChatMessageType[]>([systemMessage]);
  const [workbenchContent, setWorkbenchContent] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [rules, setRules] = useState<InterpretationRule[]>([]);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  
  // --- WebGazer State ---
  const [isWebGazerInitialized, setIsWebGazerInitialized] = useState(false);
  const handleDwell = useCallback((element: HTMLElement) => {
    element.click();
  }, []);
  const { isGazeActive, gazePosition, toggleGaze, isDwelling } = useWebGazer(isWebGazerInitialized, handleDwell);


  // --- Rule & Command Processing ---

  const processCommand = async (command: string) => {
    const trigger = command.split(' ')[0].toLowerCase();
    const rule = rules.find(r => r.trigger === trigger);

    if (rule) {
      // Basic parameter parsing
      const raw = command.substring(trigger.length).trim();
      const params: CommandParams = {
        raw,
        properties: {}, // more advanced parsing could be added here
        data: workbenchContent
      };
      
      const result = await Promise.resolve(rule.action(params));
      setChatHistory(prev => [...prev, { role: 'system', text: result, isAction: true }]);
    } else {
      setChatHistory(prev => [...prev, { role: 'system', text: `Unknown command: ${trigger}`, isAction: true }]);
    }
  };

  const handleUserInput = async (input: string) => {
    const userMessage: ChatMessageType = { role: 'user', text: input };
    setChatHistory(prev => [...prev, userMessage]);
    setIsLoading(true);

    if (input.trim().startsWith('/')) {
      await processCommand(input.trim().substring(1));
      setIsLoading(false);
      return;
    }
    
    // Pass only relevant history to the API
    const apiHistory = chatHistory.filter(m => m.role === 'user' || m.role === 'model');
    const responseText = await getCognitivePartnerResponse(input, apiHistory);
    
    // Check for rule suggestion
    const ruleRegex = /@@RULE@@([\s\S]*?)@@RULE@@/;
    const match = responseText.match(ruleRegex);
    let cleanText = responseText;
    let suggestion: SuggestedRule | undefined = undefined;
    
    if (match && match[1]) {
      try {
        suggestion = JSON.parse(match[1].trim());
        cleanText = responseText.replace(ruleRegex, '').trim();
      } catch (e) {
        console.error("Failed to parse suggested rule:", e);
      }
    }

    const modelMessage: ChatMessageType = { role: 'model', text: cleanText, suggestion };
    setChatHistory(prev => [...prev, modelMessage]);
    setIsLoading(false);
  };
  
  const addCustomRule = (newRule: SuggestedRule) => {
     if (rules.some(r => r.trigger === newRule.trigger)) {
      setChatHistory(prev => [...prev, { role: 'system', text: `Rule with trigger "${newRule.trigger}" already exists. Integration aborted.`, isAction: true }]);
      return;
    }
    
    const actionRule: InterpretationRule = {
      ...newRule,
      isDefault: false,
      action: async (params: CommandParams) => {
        // A custom rule's action is to ask the AI what to do.
        const prompt = `Execute the command "${newRule.trigger}" which means "${newRule.interpretation}". The operator provided the following parameters: "${params.raw}". The current workbench contains: "${params.data}". Respond with only the result or a confirmation.`;
        
        setIsLoading(true);
        const responseText = await getCognitivePartnerResponse(prompt, chatHistory);
        setIsLoading(false);
        
        setChatHistory(prev => [...prev, { role: 'model', text: responseText }]);
        return `Executed custom command: ${newRule.trigger}`;
      }
    };
    
    setRules(prev => [...prev, actionRule]);
    setChatHistory(prev => [...prev, { role: 'system', text: `New rule "${newRule.trigger}" integrated into engine.`, isAction: true }]);
  };
  
  const onLoadWorkspace = useCallback((workspace: SavedWorkspace) => {
    setWorkbenchContent(workspace.workbenchContent);
    
    // Reset rules to default before applying workspace custom rules
    const baseRules = puzzleTools(setWorkbenchContent);
    setRules(baseRules);
    
    // Re-hydrate custom rules from the loaded workspace
    workspace.customRules.forEach(addCustomRule);
    
    setChatHistory(prev => [...prev, { role: 'system', text: `Workspace "${workspace.name}" loaded.`}]);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // --- Effects ---
  useEffect(() => {
    // Load default tools on mount
    setRules(puzzleTools(setWorkbenchContent));
  }, []);

  useEffect(() => {
    // Scroll to bottom of chat
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chatHistory]);
  
   useEffect(() => {
    // Initialize WebGazer
    if (window.webgazer) {
      window.webgazer.begin().then(() => {
          setIsWebGazerInitialized(true);
          window.webgazer.pause();
          window.webgazer.showPredictionPoints(false);
          console.log('WebGazer Initialized');
      }).catch((err: any) => console.error("WebGazer failed to begin:", err));
    }
  }, []);


  return (
    <div className="dark bg-p-dark text-p-cyan/90 min-h-screen font-sans flex flex-col">
      {/* Gaze Dot */}
      {isGazeActive && (
         <div 
            id="gaze-dot"
            className={`fixed w-6 h-6 -translate-x-1/2 -translate-y-1/2 rounded-full pointer-events-none z-[100] transition-all duration-100 ${isDwelling ? 'bg-p-pink/80 scale-150 border-4 border-p-dark' : 'bg-p-cyan/50 scale-100'}`}
            style={{ left: `${gazePosition.x}px`, top: `${gazePosition.y}px` }}
        />
      )}

      <header className="flex justify-between items-center p-4 border-b-2 border-p-purple/50">
        <h1 className="text-2xl font-bold tracking-widest text-p-cyan animate-glow">
          Cognitive Partner Interface
        </h1>
        {isWebGazerInitialized && (
            <button onClick={toggleGaze} className="flex items-center gap-2 px-3 py-2 text-sm rounded-md bg-p-purple/50 text-p-cyan hover:bg-p-purple" data-gazeable="true">
                {isGazeActive ? <EyeOpenIcon /> : <EyeClosedIcon />}
                {isGazeActive ? "Gaze Active" : "Gaze Inactive"}
            </button>
        )}
      </header>
      
      <WorkspaceManager 
        workbenchContent={workbenchContent} 
        customRules={rules.filter(r => !r.isDefault)}
        onLoadWorkspace={onLoadWorkspace}
      />

      <main className="flex-grow grid grid-cols-1 lg:grid-cols-2 gap-4 p-4 pb-32"> {/* padding-bottom for command bar */}
        {/* Left Panel: Workbench and Tools */}
        <div className="flex flex-col gap-4">
          <div className="flex-grow flex flex-col rounded-lg glass-pane border border-p-cyan/50">
            <h2 className="text-xl font-bold p-3 border-b border-p-purple">Workbench</h2>
            <div className="flex-grow">
              <SyntaxHighlightedTextarea
                value={workbenchContent}
                onChange={setWorkbenchContent}
                placeholder="Workbench area for keys, data, and code snippets..."
              />
            </div>
          </div>
          <InteractiveTools rules={rules} onExecute={(trigger) => handleUserInput(`/${trigger}`)} />
          <HDWalletVisualizer onDerive={(info) => setWorkbenchContent(JSON.stringify(info, null, 2))} />
        </div>

        {/* Right Panel: Chat Interface */}
        <div ref={chatContainerRef} className="flex flex-col gap-2 p-4 rounded-lg glass-pane border border-p-cyan/50 max-h-[calc(100vh-120px)] overflow-y-auto">
           {chatHistory.map((msg, index) => (
            <ChatMessage key={index} message={msg} onAddRule={addCustomRule} />
          ))}
           {isLoading && <ChatMessage message={{ role: 'model', text: 'Processing...' }} />}
        </div>
      </main>

      <GlobalCommandBar onSubmit={handleUserInput} isLoading={isLoading} rules={rules} />
    </div>
  );
};

export default App;
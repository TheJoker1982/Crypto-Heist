import { ReactNode } from "react";

export interface SuggestedRule {
    trigger: string;
    interpretation: string;
    type: string;
}

// --- New Types for Advanced Command Parsing ---
export interface CommandParams {
    raw: string; // The raw, unprocessed text after the trigger
    properties: Record<string, string>; // Key-value pairs like "payload: ..."
    data: string; // Block of data after properties
}

export interface InterpretationRule extends SuggestedRule {
    action: (params: CommandParams) => Promise<string> | string;
    isDefault?: boolean; // Flag to distinguish core rules from saved/added ones
}


export interface ChatMessage {
    role: 'user' | 'model' | 'system';
    text: string;
    isAction?: boolean;
    suggestion?: SuggestedRule;
}

export interface GazePosition {
    x: number;
    y: number;
}

export interface DerivedKeyInfo {
    path: string;
    address: string;
    pubkey: string;
    error?: string;
}

// --- New Types for Workspace Management ---
export interface SavedWorkspace {
    name: string;
    timestamp: number;
    workbenchContent: string;
    customRules: SuggestedRule[];
}

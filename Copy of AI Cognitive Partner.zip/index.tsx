import React from 'react';
import ReactDOM from 'react-dom/client';
// FIX: Explicitly add the .tsx extension to resolve module import errors in certain environments.
import App from './App.tsx';
import './styles.css';

// The global Buffer object is now polyfilled in index.html to ensure it's available
// before any modules (like bitcoinjs-lib) that depend on it are loaded.

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);